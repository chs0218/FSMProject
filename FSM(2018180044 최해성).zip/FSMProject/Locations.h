#pragma once
enum location_type
{
	home,
	library,
	pcRoom,
	pizzaStore,
	road
};